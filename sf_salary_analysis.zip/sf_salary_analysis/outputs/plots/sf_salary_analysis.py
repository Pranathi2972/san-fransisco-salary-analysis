# STEP A: Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

print("Step A complete: Libraries imported")

# STEP B: Load dataset
df = pd.read_csv("data/salaries.csv")

print("Step B complete: Dataset loaded")
print("Shape:", df.shape)
print(df.head())

# STEP C: Basic dataset information
print("\nStep C: Dataset Info")
print(df.info())

print("\nMissing values in each column:")
print(df.isnull().sum())

# STEP D: Clean salary columns
salary_cols = [
    "BasePay", "OvertimePay", "OtherPay",
    "Benefits", "TotalPay", "TotalPayBenefits"
]

for col in salary_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

print("\nStep D complete: Salary columns converted to numeric")
print(df[salary_cols].head())

# STEP E: Handle missing values
df[salary_cols] = df[salary_cols].fillna(0)

print("\nStep E complete: Missing values filled with 0")
print(df[salary_cols].isnull().sum())

# STEP F: Remove invalid salary rows
initial_rows = df.shape[0]

df = df[df["TotalPayBenefits"] > 0]

final_rows = df.shape[0]

print(f"\nStep F complete: Removed {initial_rows - final_rows} invalid rows")
print("Remaining rows:", final_rows)

# STEP G: Distribution of Total Salary
plt.figure(figsize=(8, 5))
sns.histplot(df["TotalPayBenefits"], bins=50, kde=True)
plt.title("Distribution of Total Pay + Benefits")
plt.xlabel("Total Pay + Benefits")
plt.ylabel("Number of Employees")
plt.tight_layout()
plt.savefig("outputs/plots/total_salary_distribution.png")
plt.close()

print("Step G complete: Salary distribution plot saved")

# STEP H: Top 10 highest paid job titles
top_jobs = (
    df.groupby("JobTitle")["TotalPayBenefits"]
    .mean()
    .sort_values(ascending=False)
    .head(10)
)

plt.figure(figsize=(9, 5))
sns.barplot(x=top_jobs.values, y=top_jobs.index)
plt.title("Top 10 Highest Paid Job Titles (Average Salary)")
plt.xlabel("Average Total Pay + Benefits")
plt.ylabel("Job Title")
plt.tight_layout()
plt.savefig("outputs/plots/top_10_job_titles.png")
plt.close()

print("Step H complete: Top job titles plot saved")

# STEP I: Average salary trend over years
yearly_salary = df.groupby("Year")["TotalPayBenefits"].mean()

plt.figure(figsize=(8, 5))
yearly_salary.plot(marker="o")
plt.title("Average Total Pay + Benefits Over Years")
plt.xlabel("Year")
plt.ylabel("Average Salary")
plt.grid(True)
plt.tight_layout()
plt.savefig("outputs/plots/yearly_salary_trend.png")
plt.close()

print("Step I complete: Yearly salary trend plot saved")

# STEP J: Overtime vs Total Pay
plt.figure(figsize=(8, 5))
sns.scatterplot(
    x=df["OvertimePay"],
    y=df["TotalPayBenefits"],
    alpha=0.3
)
plt.title("Overtime Pay vs Total Pay + Benefits")
plt.xlabel("Overtime Pay")
plt.ylabel("Total Pay + Benefits")
plt.tight_layout()
plt.savefig("outputs/plots/overtime_vs_salary.png")
plt.close()

print("Step J complete: Overtime impact plot saved")

# STEP K: Select features and target
features = ["BasePay", "OvertimePay", "OtherPay", "Benefits", "Year"]

X = df[features]
y = df["TotalPayBenefits"]

print("\nStep K complete: Features and target selected")
print("X shape:", X.shape)
print("y shape:", y.shape)

# STEP L: Train-test split
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("\nStep L complete: Train-test split done")
print("Train size:", X_train.shape[0])
print("Test size:", X_test.shape[0])

# STEP M: Train Linear Regression model
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import math

lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

print("\nStep M complete: Linear Regression model trained")

# STEP N: Evaluate model
y_pred = lr_model.predict(X_test)

mae = mean_absolute_error(y_test, y_pred)
rmse = math.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print("\n===== Linear Regression Results =====")
print("MAE:", round(mae, 2))
print("RMSE:", round(rmse, 2))
print("R² Score:", round(r2, 4))

# STEP O: Actual vs Predicted plot
plt.figure(figsize=(6, 6))
plt.scatter(y_test, y_pred, alpha=0.3)
plt.xlabel("Actual Total Pay + Benefits")
plt.ylabel("Predicted Total Pay + Benefits")
plt.title("Actual vs Predicted Salary")
plt.tight_layout()
plt.savefig("outputs/plots/lr_actual_vs_pred_salary.png")
plt.close()

print("Step O complete: Prediction plot saved")
